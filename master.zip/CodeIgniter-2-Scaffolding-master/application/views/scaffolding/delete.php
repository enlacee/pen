<p><?php echo $message; ?></p>
<p><?php echo $no; ?>&nbsp;&nbsp;|&nbsp;&nbsp;<?php echo $yes; ?>

<?php

/* End of file delete.php */
/* Location: ./application/views/scaffolding/delete.php */
